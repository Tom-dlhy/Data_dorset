#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd
import numpy as np
import matplotlib.pyplot as plt


# In[2]:


flowers_data = pd.read_csv('Flower_dataset.csv')


# In[3]:


flowers_data


# In[4]:


import seaborn as sns
sns.heatmap(flowers_data.corr(), cmap = 'YlGnBu')
plt.show()


# In[5]:


sns.pairplot(flowers_data, hue='species')


# In[6]:


data = flowers_data.values

X = data[:,0:4]
Y = data[:,4]


# In[7]:


from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, Y, test_size = 0.2)


# In[8]:


from sklearn.linear_model import LogisticRegression
model = LogisticRegression()
model.fit(X_train, y_train)


# In[9]:


prediction = model.predict(X_test)
from sklearn.metrics import accuracy_score
print(accuracy_score(y_test, prediction))


# In[10]:


from sklearn.metrics import classification_report
print(classification_report(y_test, prediction))


# In[11]:


path = 'C:/Users/delah/Desktop/Projet Data Flowers/ model.pkl'

import pickle

with open(path, 'wb') as fichier:
    pickle.dump(model, fichier)

